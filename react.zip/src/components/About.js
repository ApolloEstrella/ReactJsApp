
const About = props => {
    return (
        <h1>AboutSy</h1>
    )
}

export default About;