const Layout = props => {
    return (
        <h1>Layout</h1>
    )
}

export default Layout;