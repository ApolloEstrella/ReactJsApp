const NoPage = props => {
    return (
        <h1>No Page</h1>
    )
}

export default NoPage;